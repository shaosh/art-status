# art-status
1. Open the index.html in nw.exe
2. For now, the user is hardcoded to be kevin.

